"""
BankShield CVE Engine — Flask Backend
======================================
• Interroge la vraie API NVD  https://services.nvd.nist.gov/rest/json/cves/2.0
• Compare chaque CVE aux OS/logiciels enregistrés (CPE matching)
• Si match → envoie automatiquement un job à l'Agent PC
• Expose une API REST pour le dashboard React
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
import threading, time, datetime, uuid, requests, os, logging, re

logging.basicConfig(level=logging.INFO, format="%(asctime)s [SERVER] %(message)s")
app = Flask(__name__)
CORS(app)

# ─────────────────────────────────────────────────────────
#  CONFIG
# ─────────────────────────────────────────────────────────
NVD_BASE      = "https://services.nvd.nist.gov/rest/json/cves/2.0"
NVD_API_KEY   = os.getenv("NVD_API_KEY", "")          # optionnel mais recommandé
AGENT_URL     = os.getenv("AGENT_URL",   "http://localhost:5001")
SERVER_URL    = os.getenv("SERVER_URL",  "http://localhost:5000")
POLL_MINUTES  = int(os.getenv("POLL_MINUTES", "15"))   # intervalle de polling NVD

# ─────────────────────────────────────────────────────────
#  INVENTAIRE OS / LOGICIELS DE L'INFRASTRUCTURE BANCAIRE
#
#  Chaque entrée contient :
#    host    → IP ou hostname de la machine
#    os      → OS et version (pour le matching NVD / CPE)
#    cpe     → liste de CPE prefixes à matcher (vendor:product)
#    agent   → URL de l'agent installé sur ce host
#    fix_cmd → commande de correction par défaut
# ─────────────────────────────────────────────────────────
HOSTS = {
    "srv-web-01": {
        "name":    "Serveur Web Principal",
        "host":    "10.0.1.10",
        "os":      "Ubuntu 22.04 LTS",
        "agent":   "http://10.0.1.10:5001",
        "cpe":     ["apache:http_server", "nginx:nginx", "openssl:openssl"],
        "packages": ["apache2", "nginx", "openssl", "libssl"],
        "tags":    ["web", "dmz"],
    },
    "srv-db-01": {
        "name":    "Serveur Base de Données",
        "host":    "10.0.1.20",
        "os":      "Red Hat Enterprise Linux 9",
        "agent":   "http://10.0.1.20:5001",
        "cpe":     ["oracle:database", "postgresql:postgresql", "mysql:mysql_server"],
        "packages": ["oracle-database", "postgresql", "mysql"],
        "tags":    ["database", "internal"],
    },
    "srv-app-01": {
        "name":    "Serveur Application Java",
        "host":    "10.0.1.30",
        "os":      "Ubuntu 20.04 LTS",
        "agent":   "http://10.0.1.30:5001",
        "cpe":     ["apache:tomcat", "springframework:spring_framework",
                    "apache:log4j", "java:jdk"],
        "packages": ["tomcat9", "openjdk-17-jdk"],
        "tags":    ["app", "java"],
    },
    "srv-mq-01": {
        "name":    "Serveur Messagerie",
        "host":    "10.0.1.40",
        "os":      "Windows Server 2022",
        "agent":   "http://10.0.1.40:5001",
        "cpe":     ["ibm:mq", "rabbitmq:rabbitmq_server", "microsoft:windows_server"],
        "packages": ["IBM MQ", "RabbitMQ"],
        "tags":    ["messaging", "windows"],
    },
    "srv-iam-01": {
        "name":    "Serveur IAM / Keycloak",
        "host":    "10.0.1.70",
        "os":      "Ubuntu 22.04 LTS",
        "agent":   "http://10.0.1.70:5001",
        "cpe":     ["redhat:keycloak", "springframework:spring_security"],
        "packages": ["keycloak"],
        "tags":    ["iam", "auth"],
    },
    "srv-cache-01": {
        "name":    "Serveur Cache Redis",
        "host":    "10.0.1.50",
        "os":      "Debian 12",
        "agent":   "http://10.0.1.50:5001",
        "cpe":     ["redis:redis"],
        "packages": ["redis-server"],
        "tags":    ["cache", "internal"],
    },
    "srv-swift-01": {
        "name":    "Passerelle SWIFT",
        "host":    "10.0.1.60",
        "os":      "Windows Server 2019",
        "agent":   "http://10.0.1.60:5001",
        "cpe":     ["swift:alliance_gateway", "microsoft:windows_server",
                    "microsoft:iis"],
        "packages": ["SWIFT Alliance", "IIS"],
        "tags":    ["payment", "critical", "windows"],
    },
    "srv-container-01": {
        "name":    "Hôte Docker / K8s",
        "host":    "10.0.1.80",
        "os":      "Ubuntu 22.04 LTS",
        "agent":   "http://10.0.1.80:5001",
        "cpe":     ["docker:docker", "kubernetes:kubernetes",
                    "linux:linux_kernel"],
        "packages": ["docker-ce", "kubectl", "containerd"],
        "tags":    ["container", "infra"],
    },
}

# ─────────────────────────────────────────────────────────
#  IN-MEMORY STORE
# ─────────────────────────────────────────────────────────
cve_store  = {}   # cve_id  → CVE dict
job_store  = {}   # job_id  → Job dict
lock       = threading.Lock()

# ─────────────────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────────────────
def now_iso():
    return datetime.datetime.utcnow().isoformat() + "Z"

def now_hm():
    return datetime.datetime.utcnow().strftime("%H:%M:%S")

# ─────────────────────────────────────────────────────────
#  NVD FETCHER
# ─────────────────────────────────────────────────────────
def fetch_nvd(hours_back: int = 24) -> list[dict]:
    """
    Interroge l'API NVD officielle et retourne une liste de CVE normalisées.
    https://services.nvd.nist.gov/rest/json/cves/2.0
    """
    end   = datetime.datetime.utcnow()
    start = end - datetime.timedelta(hours=hours_back)

    params = {
        "pubStartDate": start.strftime("%Y-%m-%dT%H:%M:%S.000"),
        "pubEndDate":   end.strftime("%Y-%m-%dT%H:%M:%S.000"),
        "resultsPerPage": 100,
        "startIndex":   0,
    }
    headers = {}
    if NVD_API_KEY:
        headers["apiKey"] = NVD_API_KEY

    all_cves = []
    try:
        logging.info(f"[NVD] Polling {NVD_BASE} (last {hours_back}h)...")
        resp = requests.get(NVD_BASE, params=params, headers=headers, timeout=20)
        resp.raise_for_status()
        data = resp.json()

        total = data.get("totalResults", 0)
        logging.info(f"[NVD] {total} CVE trouvées")

        for item in data.get("vulnerabilities", []):
            cve_raw = item.get("cve", {})
            cve_id  = cve_raw.get("id", "")
            if not cve_id:
                continue

            # Description anglaise
            desc = ""
            for d in cve_raw.get("descriptions", []):
                if d.get("lang") == "en":
                    desc = d.get("value", "")
                    break

            # Score CVSS (v3.1 > v3.0 > v2)
            score, sev, vector = 0.0, "UNKNOWN", ""
            metrics = cve_raw.get("metrics", {})
            for key in ["cvssMetricV31", "cvssMetricV30", "cvssMetricV2"]:
                if key in metrics and metrics[key]:
                    m = metrics[key][0]
                    cd = m.get("cvssData", {})
                    score  = cd.get("baseScore", 0.0)
                    sev    = cd.get("baseSeverity", "")
                    vector = cd.get("vectorString", "")
                    if not sev and key == "cvssMetricV2":
                        sev = m.get("baseSeverity", "")
                    if not sev:
                        sev = "HIGH" if score >= 7 else "MEDIUM" if score >= 4 else "LOW"
                    break

            # CPE configurations (pour le matching OS)
            cpes = []
            for cfg in cve_raw.get("configurations", []):
                for node in cfg.get("nodes", []):
                    for match in node.get("cpeMatch", []):
                        uri = match.get("criteria", "")
                        if uri:
                            cpes.append(uri.lower())

            # Références
            refs = [r.get("url","") for r in cve_raw.get("references", [])[:3]]

            all_cves.append({
                "id":          cve_id,
                "description": desc,
                "score":       score,
                "severity":    sev.upper() if sev else "UNKNOWN",
                "vector":      vector,
                "cpes":        cpes,
                "references":  refs,
                "published":   cve_raw.get("published", now_iso()),
                "modified":    cve_raw.get("lastModified", now_iso()),
                "source":      "NVD",
            })

    except requests.exceptions.HTTPError as e:
        logging.error(f"[NVD] HTTP error: {e}")
    except Exception as e:
        logging.error(f"[NVD] Fetch error: {e}")

    return all_cves

# ─────────────────────────────────────────────────────────
#  OS / CPE MATCHER
# ─────────────────────────────────────────────────────────
def match_hosts(cve: dict) -> list[str]:
    """
    Compare les CPE du CVE avec l'inventaire des hosts.
    Retourne la liste des host_ids affectés.
    """
    cve_cpes = cve.get("cpes", [])
    cve_desc = cve.get("description", "").lower()
    cve_id   = cve.get("id", "").lower()
    affected = []

    for host_id, host in HOSTS.items():
        matched = False

        # 1. Match CPE (le plus précis)
        for host_cpe in host.get("cpe", []):
            vendor, product = host_cpe.split(":", 1) if ":" in host_cpe else (host_cpe, "")
            for cve_cpe in cve_cpes:
                # Format NVD CPE:  cpe:2.3:a:vendor:product:version:...
                if vendor in cve_cpe and product in cve_cpe:
                    matched = True
                    break
            if matched:
                break

        # 2. Match par mots-clés dans la description (fallback)
        if not matched:
            keywords = []
            for cpe in host.get("cpe", []):
                parts = cpe.replace("_", " ").split(":")
                keywords.extend(parts)
            for pkg in host.get("packages", []):
                keywords.append(pkg.lower())

            for kw in keywords:
                if len(kw) > 3 and kw in cve_desc:
                    matched = True
                    break

        if matched:
            affected.append(host_id)

    return affected

# ─────────────────────────────────────────────────────────
#  BACKGROUND POLLING LOOP
# ─────────────────────────────────────────────────────────
_last_poll = None

def polling_loop():
    global _last_poll
    # Premier poll au démarrage
    _poll_and_process(hours_back=24)
    while True:
        time.sleep(POLL_MINUTES * 60)
        _poll_and_process(hours_back=POLL_MINUTES / 60 + 0.5)

def _poll_and_process(hours_back: float = 1.0):
    global _last_poll
    _last_poll = now_iso()
    fresh = fetch_nvd(hours_back=max(1, int(hours_back)))

    new_count = 0
    for cve in fresh:
        cid = cve["id"]
        with lock:
            already_known = cid in cve_store

        if already_known:
            continue

        affected_hosts = match_hosts(cve)
        cve["affected_hosts"] = affected_hosts
        cve["status"]         = "new"
        cve["detected_at"]    = now_iso()

        with lock:
            cve_store[cid] = cve
        new_count += 1

        logging.info(f"[CVE] {cid} [{cve['severity']}] score={cve['score']}")
        if affected_hosts:
            logging.info(f"  └─ Hosts affectés: {affected_hosts}")
            # Auto-dispatch si CRITICAL ou HIGH
            if cve["severity"] in ("CRITICAL", "HIGH"):
                _auto_dispatch(cve)

    logging.info(f"[POLL] {new_count} nouveaux CVE traités")

# ─────────────────────────────────────────────────────────
#  AUTO-DISPATCH VERS AGENT
# ─────────────────────────────────────────────────────────
def _auto_dispatch(cve: dict):
    """Pour chaque host affecté, crée un job et l'envoie à l'agent."""
    for host_id in cve.get("affected_hosts", []):
        host = HOSTS.get(host_id)
        if not host:
            continue

        job_id = str(uuid.uuid4())[:8].upper()
        job = {
            "job_id":      job_id,
            "cve_id":      cve["id"],
            "severity":    cve["severity"],
            "score":       cve["score"],
            "host_id":     host_id,
            "host_name":   host["name"],
            "host_ip":     host["host"],
            "host_os":     host["os"],
            "status":      "queued",
            "auto":        True,
            "created_at":  now_iso(),
            "updated_at":  now_iso(),
            "log":         [],
        }
        with lock:
            job_store[job_id] = job
            cve_store[cve["id"]]["status"] = "analyzing"

        logging.info(f"[DISPATCH] Job {job_id} → {host['host']} ({host['os']}) pour {cve['id']}")
        threading.Thread(
            target=_send_to_agent,
            args=(job_id, cve, host),
            daemon=True
        ).start()

def _send_to_agent(job_id: str, cve: dict, host: dict):
    """Envoie le job à l'agent via HTTP POST /execute."""
    payload = {
        "job_id":      job_id,
        "cve_id":      cve["id"],
        "severity":    cve["severity"],
        "score":       cve["score"],
        "vector":      cve.get("vector", ""),
        "description": cve.get("description", ""),
        "host_os":     host["os"],
        "host_id":     host.get("host", ""),
        "packages":    host.get("packages", []),
        "cpe":         host.get("cpe", []),
        "callback_url": f"{SERVER_URL}/api/agent/callback",
    }

    agent_url = host.get("agent", AGENT_URL)

    with lock:
        job_store[job_id]["status"] = "dispatched"
        job_store[job_id]["log"].append(f"[{now_hm()}] Job envoyé à l'agent {agent_url}")

    try:
        resp = requests.post(f"{agent_url}/execute", json=payload, timeout=8)
        if resp.status_code == 200:
            logging.info(f"[AGENT] Job {job_id} accepté par {agent_url}")
            with lock:
                job_store[job_id]["status"] = "running"
                job_store[job_id]["log"].append(f"[{now_hm()}] Agent a accepté le job")
        else:
            raise Exception(f"Agent HTTP {resp.status_code}")

    except Exception as e:
        logging.warning(f"[AGENT] Unreachable ({e}) — simulation locale")
        with lock:
            job_store[job_id]["log"].append(f"[{now_hm()}] Agent injoignable — simulation")
        threading.Thread(
            target=_simulate_fix, args=(job_id, cve, host), daemon=True
        ).start()

def _simulate_fix(job_id: str, cve: dict, host: dict):
    """Simulation de la correction quand l'agent est offline (mode démo)."""
    steps = [
        f"Connexion SSH → {host['host']} ({host['os']})",
        f"Identification des paquets vulnérables",
        f"Téléchargement des correctifs pour {cve['id']}",
        f"Sauvegarde de la configuration",
        f"Application des patches système...",
        f"Redémarrage des services affectés",
        f"Vérification de l'intégrité post-patch",
        f"Scan de confirmation — CVE {cve['id']} : RÉSOLU",
    ]
    time.sleep(2)
    for step in steps:
        time.sleep(1.5 + len(host.get("packages",[])) * 0.2)
        with lock:
            if job_id in job_store:
                job_store[job_id]["log"].append(f"[{now_hm()}] {step}")

    with lock:
        if job_id in job_store:
            job_store[job_id]["status"]     = "patched"
            job_store[job_id]["updated_at"] = now_iso()
        cid = job_store[job_id]["cve_id"] if job_id in job_store else None
        if cid and cid in cve_store:
            # Patché seulement si tous les jobs de ce CVE sont finis
            all_jobs = [j for j in job_store.values() if j["cve_id"] == cid]
            if all(j["status"] in ("patched","failed") for j in all_jobs):
                cve_store[cid]["status"]     = "patched"
                cve_store[cid]["patched_at"] = now_iso()

    logging.info(f"[SIM] Job {job_id} simulé — patché")

# ─────────────────────────────────────────────────────────
#  API ROUTES
# ─────────────────────────────────────────────────────────

@app.get("/api/warn")
def api_warn():
    sev_f    = request.args.get("severity","").upper()
    status_f = request.args.get("status","")
    with lock:
        items = list(cve_store.values())
    if sev_f:
        items = [c for c in items if c.get("severity") == sev_f]
    if status_f:
        items = [c for c in items if c.get("status") == status_f]
    items.sort(key=lambda c: c.get("score",0), reverse=True)

    summary = {
        "total":    len(items),
        "critical": sum(1 for c in items if c["severity"] == "CRITICAL"),
        "high":     sum(1 for c in items if c["severity"] == "HIGH"),
        "medium":   sum(1 for c in items if c["severity"] == "MEDIUM"),
        "affected": sum(1 for c in items if c.get("affected_hosts")),
        "patched":  sum(1 for c in items if c.get("status") == "patched"),
        "last_poll": _last_poll,
    }
    return jsonify({"ok": True, "summary": summary, "cves": items})


@app.post("/api/auto_fix")
def api_auto_fix():
    body   = request.get_json(force=True) or {}
    cve_id = body.get("cve_id","").strip()
    if not cve_id:
        return jsonify({"ok": False, "error": "cve_id required"}), 400
    with lock:
        cve = cve_store.get(cve_id)
    if not cve:
        return jsonify({"ok": False, "error": f"{cve_id} not found"}), 404
    if cve.get("status") == "patched":
        return jsonify({"ok": True, "message": "Already patched"})

    job_ids = []
    for host_id in cve.get("affected_hosts", []):
        host   = HOSTS.get(host_id)
        if not host: continue
        job_id = str(uuid.uuid4())[:8].upper()
        job = {
            "job_id": job_id, "cve_id": cve_id,
            "severity": cve["severity"], "score": cve["score"],
            "host_id": host_id, "host_name": host["name"],
            "host_ip": host["host"], "host_os": host["os"],
            "status": "queued", "auto": False,
            "created_at": now_iso(), "updated_at": now_iso(), "log": [],
        }
        with lock:
            job_store[job_id] = job
            cve_store[cve_id]["status"] = "analyzing"
        threading.Thread(target=_send_to_agent, args=(job_id, cve, host), daemon=True).start()
        job_ids.append(job_id)

    return jsonify({"ok": True, "job_ids": job_ids, "hosts": len(job_ids)})


@app.post("/api/agent/callback")
def api_callback():
    body   = request.get_json(force=True) or {}
    job_id = body.get("job_id","").upper()
    result = body.get("result","unknown")
    log    = body.get("log", [])
    with lock:
        job = job_store.get(job_id)
        if job:
            job["status"]     = "patched" if result == "success" else "failed"
            job["updated_at"] = now_iso()
            job["log"].extend(log)
            cid = job["cve_id"]
            if cid in cve_store:
                all_jobs = [j for j in job_store.values() if j["cve_id"] == cid]
                if all(j["status"] in ("patched","failed") for j in all_jobs):
                    cve_store[cid]["status"]     = "patched" if result=="success" else "failed"
                    cve_store[cid]["patched_at"] = now_iso()
    return jsonify({"ok": True})


@app.get("/api/jobs")
def api_jobs():
    with lock:
        jobs = sorted(job_store.values(), key=lambda j: j["created_at"], reverse=True)
    return jsonify({"ok": True, "jobs": jobs[:50]})


@app.get("/api/hosts")
def api_hosts():
    with lock:
        cves = list(cve_store.values())
    result = {}
    for hid, h in HOSTS.items():
        active = [c["id"] for c in cves
                  if hid in c.get("affected_hosts",[]) and c.get("status") != "patched"]
        status = "ok"
        if any(c for c in cves if hid in c.get("affected_hosts",[])
               and c.get("status") != "patched" and c["severity"] == "CRITICAL"):
            status = "critical"
        elif active:
            status = "warning"
        result[hid] = {**h, "status": status, "active_cves": active, "cve_count": len(active)}
    return jsonify({"ok": True, "hosts": result})


@app.post("/api/poll")
def api_manual_poll():
    """Déclenche un poll NVD immédiat (bouton refresh dashboard)."""
    hours = int(request.get_json(force=True, silent=True, cache=False).get("hours", 24) if request.data else 24)
    threading.Thread(target=_poll_and_process, args=(hours,), daemon=True).start()
    return jsonify({"ok": True, "message": f"Polling NVD (last {hours}h) lancé"})


@app.get("/api/health")
def api_health():
    with lock:
        total = len(cve_store); jobs = len(job_store)
    return jsonify({
        "ok": True, "cves": total, "jobs": jobs,
        "last_poll": _last_poll, "nvd_key": bool(NVD_API_KEY),
        "poll_interval_min": POLL_MINUTES,
    })


# ─────────────────────────────────────────────────────────
#  START
# ─────────────────────────────────────────────────────────
threading.Thread(target=polling_loop, daemon=True).start()

if __name__ == "__main__":
    logging.info("=" * 55)
    logging.info("  BankShield CVE Engine  —  Flask Server")
    logging.info(f"  NVD Key   : {'✓ présente' if NVD_API_KEY else '✗ absente (rate-limit: 5req/30s)'}")
    logging.info(f"  Agent URL : {AGENT_URL}")
    logging.info(f"  Poll      : toutes les {POLL_MINUTES} minutes")
    logging.info("=" * 55)
    app.run(host="0.0.0.0", port=5000, debug=False)
