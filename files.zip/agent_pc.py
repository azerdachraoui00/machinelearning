"""
BankShield Agent PC
====================
• Reçoit un job depuis Flask Server  POST /execute
• Détecte l'OS réel de la machine
• Exécute le script de correction adapté
• Renvoie le résultat complet au serveur via callback HTTP

Usage:
    python agent.py
    NVD_AGENT_SECRET=xxx SERVER_URL=http://10.0.1.Y:5000 python agent.py
"""

from flask import Flask, jsonify, request
import subprocess, threading, time, datetime, os, platform, shutil
import requests, logging, json

logging.basicConfig(level=logging.INFO, format="%(asctime)s [AGENT] %(message)s")
app   = Flask(__name__)
SECRET      = os.getenv("NVD_AGENT_SECRET", "bankshield-2024")
SERVER_URL  = os.getenv("SERVER_URL",       "http://localhost:5000")
SCRIPTS_DIR = os.path.join(os.path.dirname(__file__), "fix_scripts")
os.makedirs(SCRIPTS_DIR, exist_ok=True)

# ─────────────────────────────────────────────
#  OS DETECTION
# ─────────────────────────────────────────────
def detect_os() -> dict:
    """Détecte l'OS et les gestionnaires de paquets disponibles."""
    info = {
        "platform":    platform.system(),          # Linux / Windows / Darwin
        "release":     platform.release(),
        "version":     platform.version(),
        "machine":     platform.machine(),
        "node":        platform.node(),
        "pkg_manager": None,
        "distro":      "",
    }
    if platform.system() == "Linux":
        # Détecter la distro
        try:
            with open("/etc/os-release") as f:
                for line in f:
                    if line.startswith("PRETTY_NAME="):
                        info["distro"] = line.split("=",1)[1].strip().strip('"')
        except:
            pass
        # Gestionnaire de paquets
        for mgr in ["apt-get","yum","dnf","zypper","pacman","apk"]:
            if shutil.which(mgr):
                info["pkg_manager"] = mgr
                break

    elif platform.system() == "Windows":
        info["distro"] = platform.version()
        for mgr in ["winget","choco","scoop"]:
            if shutil.which(mgr):
                info["pkg_manager"] = mgr
                break

    elif platform.system() == "Darwin":
        info["distro"] = "macOS"
        if shutil.which("brew"):
            info["pkg_manager"] = "brew"

    return info

OS_INFO = detect_os()
logging.info(f"OS détecté: {OS_INFO['platform']} {OS_INFO['distro']} — pkg: {OS_INFO['pkg_manager']}")

# ─────────────────────────────────────────────
#  PATCH STRATEGY MAP
#  Associe chaque CPE / mot-clé à une action
# ─────────────────────────────────────────────
PATCH_STRATEGIES = {
    # Linux (apt/yum/dnf)
    "apache:http_server":         {"pkg": "apache2",          "service": "apache2"},
    "apache:httpd":               {"pkg": "httpd",            "service": "httpd"},
    "nginx:nginx":                {"pkg": "nginx",            "service": "nginx"},
    "openssl:openssl":            {"pkg": "openssl",          "service": None},
    "postgresql:postgresql":      {"pkg": "postgresql",       "service": "postgresql"},
    "redis:redis":                {"pkg": "redis-server",     "service": "redis"},
    "apache:tomcat":              {"pkg": "tomcat9",          "service": "tomcat9"},
    "apache:log4j":               {"pkg": None,               "service": None, "custom": "fix_log4j"},
    "springframework:spring":     {"pkg": None,               "service": None, "custom": "fix_spring"},
    "redhat:keycloak":            {"pkg": "keycloak",         "service": "keycloak"},
    "docker:docker":              {"pkg": "docker-ce",        "service": "docker"},
    "linux:linux_kernel":         {"pkg": "linux-image-generic","service": None},
    # Windows (winget/choco)
    "ibm:mq":                     {"pkg": None, "service": None, "custom": "fix_ibm_mq"},
    "microsoft:windows_server":   {"pkg": None, "service": None, "custom": "fix_windows_update"},
    "swift:alliance":             {"pkg": None, "service": None, "custom": "fix_swift"},
}

# ─────────────────────────────────────────────
#  ROUTE: POST /execute
# ─────────────────────────────────────────────
@app.post("/execute")
def execute():
    body = request.get_json(force=True) or {}
    # Auth légère
    if body.get("secret","") != SECRET and \
       request.headers.get("X-Agent-Secret","") != SECRET:
        pass  # On accepte en démo — mettre stricte en prod

    job_id      = body.get("job_id", "")
    cve_id      = body.get("cve_id", "")
    cpe_list    = body.get("cpe", [])
    packages    = body.get("packages", [])
    callback    = body.get("callback_url", f"{SERVER_URL}/api/agent/callback")

    if not job_id or not cve_id:
        return jsonify({"ok": False, "error": "job_id + cve_id required"}), 400

    logging.info(f"Job {job_id} reçu — CVE: {cve_id} — packages: {packages}")

    threading.Thread(
        target=_run_fix,
        args=(job_id, cve_id, cpe_list, packages, callback),
        daemon=True
    ).start()

    return jsonify({"ok": True, "job_id": job_id, "os": OS_INFO["platform"]})


@app.get("/health")
def health():
    return jsonify({"ok": True, "os": OS_INFO, "pkg_manager": OS_INFO["pkg_manager"]})


# ─────────────────────────────────────────────
#  CORE FIX RUNNER
# ─────────────────────────────────────────────
def _run_fix(job_id, cve_id, cpe_list, packages, callback_url):
    log     = []
    success = True

    def L(msg, level="INFO"):
        ts    = datetime.datetime.utcnow().strftime("%H:%M:%S")
        entry = f"[{ts}] {msg}"
        log.append(entry)
        logging.info(f"[{job_id}] {msg}")

    L(f"=== JOB {job_id} DÉMARRÉ ===")
    L(f"CVE       : {cve_id}")
    L(f"OS        : {OS_INFO['platform']} {OS_INFO.get('distro','')}")
    L(f"Pkg mgr   : {OS_INFO['pkg_manager']}")
    L(f"CPE cibles: {cpe_list}")
    L(f"Paquets   : {packages}")

    # Résoudre les stratégies de patch applicables
    strategies = _resolve_strategies(cpe_list, packages)
    if not strategies:
        L("Aucune stratégie de patch spécifique — application des mises à jour générales")
        strategies = [{"type": "general_update"}]

    for strat in strategies:
        L(f"--- Stratégie: {strat} ---")
        ok = _apply_strategy(strat, cve_id, L)
        if not ok:
            success = False

    L(f"=== JOB {job_id} {'SUCCÈS' if success else 'ÉCHEC'} ===")
    _send_callback(callback_url, job_id, "success" if success else "failed", log)


def _resolve_strategies(cpe_list, packages):
    """Trouve les stratégies de patch pour les CPE / paquets donnés."""
    found = []
    for cpe in cpe_list:
        for key, strat in PATCH_STRATEGIES.items():
            if key in cpe or any(p in cpe for p in key.split(":")):
                s = {**strat, "cpe": cpe, "key": key}
                if s not in found:
                    found.append(s)
    # Fallback: chercher par nom de paquet
    if not found:
        for pkg in packages:
            found.append({"pkg": pkg.lower(), "service": None, "type": "pkg_upgrade"})
    return found


def _apply_strategy(strat: dict, cve_id: str, L) -> bool:
    """Applique une stratégie de patch selon l'OS."""
    # Script custom prioritaire
    custom = strat.get("custom")
    if custom:
        return _run_script(custom, cve_id, L)

    pkg     = strat.get("pkg")
    service = strat.get("service")
    pm      = OS_INFO["pkg_manager"]

    if not pkg:
        L("Pas de paquet à mettre à jour pour cette stratégie")
        return True

    if pm in ("apt-get", "apt"):
        return _apt_upgrade(pkg, service, L)
    elif pm in ("yum", "dnf"):
        return _yum_upgrade(pkg, service, L)
    elif pm == "zypper":
        return _zypper_upgrade(pkg, service, L)
    elif pm == "winget":
        return _winget_upgrade(pkg, service, L)
    elif pm == "choco":
        return _choco_upgrade(pkg, service, L)
    elif pm == "brew":
        return _brew_upgrade(pkg, service, L)
    else:
        L(f"Gestionnaire de paquets '{pm}' non supporté — simulation")
        return _simulate_steps(pkg, service, L)


# ─── PACKAGE MANAGERS ──────────────────────────────────

def _apt_upgrade(pkg, service, L) -> bool:
    L(f"apt-get update + upgrade {pkg}")
    try:
        _run_cmd(["apt-get", "update", "-qq"],      L, check=True)
        _run_cmd(["apt-get", "install", "-y",
                  "--only-upgrade", pkg],            L, check=True)
        if service:
            _run_cmd(["systemctl", "restart", service], L, check=False)
            _run_cmd(["systemctl", "status", service, "--no-pager"], L, check=False)
        L(f"✓ {pkg} mis à jour via apt")
        return True
    except Exception as e:
        L(f"✗ apt échoué: {e}")
        return False

def _yum_upgrade(pkg, service, L) -> bool:
    L(f"yum/dnf update {pkg}")
    mgr = OS_INFO["pkg_manager"]
    try:
        _run_cmd([mgr, "update", "-y", pkg], L, check=True)
        if service:
            _run_cmd(["systemctl", "restart", service], L, check=False)
        L(f"✓ {pkg} mis à jour via {mgr}")
        return True
    except Exception as e:
        L(f"✗ {mgr} échoué: {e}")
        return False

def _zypper_upgrade(pkg, service, L) -> bool:
    try:
        _run_cmd(["zypper", "-n", "update", pkg], L, check=True)
        if service:
            _run_cmd(["systemctl", "restart", service], L, check=False)
        L(f"✓ {pkg} mis à jour via zypper")
        return True
    except Exception as e:
        L(f"✗ zypper échoué: {e}"); return False

def _winget_upgrade(pkg, service, L) -> bool:
    try:
        _run_cmd(["winget", "upgrade", "--id", pkg, "--silent",
                  "--accept-package-agreements"], L, check=True)
        L(f"✓ {pkg} mis à jour via winget")
        return True
    except Exception as e:
        L(f"✗ winget échoué: {e}"); return False

def _choco_upgrade(pkg, service, L) -> bool:
    try:
        _run_cmd(["choco", "upgrade", pkg, "-y"], L, check=True)
        L(f"✓ {pkg} mis à jour via chocolatey")
        return True
    except Exception as e:
        L(f"✗ choco échoué: {e}"); return False

def _brew_upgrade(pkg, service, L) -> bool:
    try:
        _run_cmd(["brew", "upgrade", pkg], L, check=True)
        L(f"✓ {pkg} mis à jour via brew")
        return True
    except Exception as e:
        L(f"✗ brew échoué: {e}"); return False

def _simulate_steps(pkg, service, L) -> bool:
    """Mode simulation quand le pkg manager n'est pas dispo."""
    for step in [
        f"[SIM] Recherche de mise à jour pour {pkg}",
        f"[SIM] Téléchargement du correctif",
        f"[SIM] Application du patch",
        f"[SIM] ✓ {pkg} sécurisé",
    ]:
        time.sleep(1.2)
        L(step)
    return True

def _run_cmd(cmd, L, check=True):
    """Exécute une commande shell et loggue la sortie."""
    L(f"$ {' '.join(cmd)}")
    result = subprocess.run(
        cmd, capture_output=True, text=True, timeout=120
    )
    for line in result.stdout.strip().splitlines():
        if line.strip(): L(f"  {line}")
    if result.returncode != 0:
        for line in result.stderr.strip().splitlines():
            if line.strip(): L(f"  ERR: {line}")
        if check:
            raise Exception(f"exit {result.returncode}")
    return result

def _run_script(script_name, cve_id, L) -> bool:
    """Exécute un script custom dans fix_scripts/."""
    path = os.path.join(SCRIPTS_DIR, f"{script_name}.sh")
    if not os.path.exists(path):
        L(f"Script {script_name}.sh introuvable — simulation")
        return _simulate_steps(script_name, None, L)
    try:
        L(f"Exécution script: {script_name}.sh {cve_id}")
        r = subprocess.run(
            ["bash", path, cve_id],
            capture_output=True, text=True, timeout=180
        )
        for line in r.stdout.strip().splitlines(): L(f"  {line}")
        if r.returncode != 0:
            for line in r.stderr.strip().splitlines(): L(f"  ERR: {line}")
            return False
        L(f"✓ Script {script_name} terminé")
        return True
    except Exception as e:
        L(f"✗ Script {script_name} échoué: {e}")
        return False

# ─────────────────────────────────────────────
#  CALLBACK
# ─────────────────────────────────────────────
def _send_callback(url, job_id, result, log):
    payload = {"job_id": job_id, "result": result, "log": log}
    for attempt in range(4):
        try:
            r = requests.post(url, json=payload, timeout=8)
            if r.status_code == 200:
                logging.info(f"Callback OK — job {job_id}: {result}")
                return
        except Exception as e:
            logging.warning(f"Callback tentative {attempt+1}: {e}")
            time.sleep(3)
    logging.error(f"Callback définitivement échoué pour job {job_id}")


if __name__ == "__main__":
    logging.info("=" * 50)
    logging.info("  BankShield Agent PC — port 5001")
    logging.info(f"  OS: {OS_INFO['platform']} {OS_INFO.get('distro','')}")
    logging.info(f"  Pkg manager: {OS_INFO['pkg_manager'] or 'aucun détecté'}")
    logging.info(f"  Scripts dir: {SCRIPTS_DIR}")
    logging.info("=" * 50)
    app.run(host="0.0.0.0", port=5001, debug=False)
